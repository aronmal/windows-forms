﻿namespace IV_TI_G21_2021_2022_Lottoziehung
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Eingabe1 = new System.Windows.Forms.TextBox();
            this.Eingabe2 = new System.Windows.Forms.TextBox();
            this.Eingabe3 = new System.Windows.Forms.TextBox();
            this.Eingabe4 = new System.Windows.Forms.TextBox();
            this.Eingabe5 = new System.Windows.Forms.TextBox();
            this.Eingabe6 = new System.Windows.Forms.TextBox();
            this.Ausgabe6 = new System.Windows.Forms.TextBox();
            this.Ausgabe5 = new System.Windows.Forms.TextBox();
            this.Ausgabe4 = new System.Windows.Forms.TextBox();
            this.Ausgabe3 = new System.Windows.Forms.TextBox();
            this.Ausgabe2 = new System.Windows.Forms.TextBox();
            this.Ausgabe1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Eingabe6);
            this.groupBox1.Controls.Add(this.Eingabe5);
            this.groupBox1.Controls.Add(this.Eingabe4);
            this.groupBox1.Controls.Add(this.Eingabe3);
            this.groupBox1.Controls.Add(this.Eingabe2);
            this.groupBox1.Controls.Add(this.Eingabe1);
            this.groupBox1.Location = new System.Drawing.Point(54, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(658, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Bitte geben Sie Ihren Lottotipp ( Zahlen 1-49) hier ein!";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Ausgabe6);
            this.groupBox2.Controls.Add(this.Ausgabe5);
            this.groupBox2.Controls.Add(this.Ausgabe4);
            this.groupBox2.Controls.Add(this.Ausgabe3);
            this.groupBox2.Controls.Add(this.Ausgabe2);
            this.groupBox2.Controls.Add(this.Ausgabe1);
            this.groupBox2.Location = new System.Drawing.Point(54, 263);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(658, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Ergebnisse der Lottoziehung";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(241, 176);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(259, 47);
            this.button1.TabIndex = 2;
            this.button1.Text = "Lottoziehung!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Eingabe1
            // 
            this.Eingabe1.Location = new System.Drawing.Point(25, 35);
            this.Eingabe1.Multiline = true;
            this.Eingabe1.Name = "Eingabe1";
            this.Eingabe1.Size = new System.Drawing.Size(68, 30);
            this.Eingabe1.TabIndex = 0;
            // 
            // Eingabe2
            // 
            this.Eingabe2.Location = new System.Drawing.Point(130, 35);
            this.Eingabe2.Multiline = true;
            this.Eingabe2.Name = "Eingabe2";
            this.Eingabe2.Size = new System.Drawing.Size(68, 30);
            this.Eingabe2.TabIndex = 1;
            // 
            // Eingabe3
            // 
            this.Eingabe3.Location = new System.Drawing.Point(237, 35);
            this.Eingabe3.Multiline = true;
            this.Eingabe3.Name = "Eingabe3";
            this.Eingabe3.Size = new System.Drawing.Size(68, 30);
            this.Eingabe3.TabIndex = 2;
            // 
            // Eingabe4
            // 
            this.Eingabe4.Location = new System.Drawing.Point(342, 35);
            this.Eingabe4.Multiline = true;
            this.Eingabe4.Name = "Eingabe4";
            this.Eingabe4.Size = new System.Drawing.Size(68, 30);
            this.Eingabe4.TabIndex = 3;
            // 
            // Eingabe5
            // 
            this.Eingabe5.Location = new System.Drawing.Point(446, 35);
            this.Eingabe5.Multiline = true;
            this.Eingabe5.Name = "Eingabe5";
            this.Eingabe5.Size = new System.Drawing.Size(68, 30);
            this.Eingabe5.TabIndex = 4;
            // 
            // Eingabe6
            // 
            this.Eingabe6.Location = new System.Drawing.Point(553, 35);
            this.Eingabe6.Multiline = true;
            this.Eingabe6.Name = "Eingabe6";
            this.Eingabe6.Size = new System.Drawing.Size(68, 30);
            this.Eingabe6.TabIndex = 5;
            // 
            // Ausgabe6
            // 
            this.Ausgabe6.Location = new System.Drawing.Point(559, 35);
            this.Ausgabe6.Multiline = true;
            this.Ausgabe6.Name = "Ausgabe6";
            this.Ausgabe6.Size = new System.Drawing.Size(68, 30);
            this.Ausgabe6.TabIndex = 11;
            // 
            // Ausgabe5
            // 
            this.Ausgabe5.Location = new System.Drawing.Point(452, 35);
            this.Ausgabe5.Multiline = true;
            this.Ausgabe5.Name = "Ausgabe5";
            this.Ausgabe5.Size = new System.Drawing.Size(68, 30);
            this.Ausgabe5.TabIndex = 10;
            // 
            // Ausgabe4
            // 
            this.Ausgabe4.Location = new System.Drawing.Point(348, 35);
            this.Ausgabe4.Multiline = true;
            this.Ausgabe4.Name = "Ausgabe4";
            this.Ausgabe4.Size = new System.Drawing.Size(68, 30);
            this.Ausgabe4.TabIndex = 9;
            // 
            // Ausgabe3
            // 
            this.Ausgabe3.Location = new System.Drawing.Point(243, 35);
            this.Ausgabe3.Multiline = true;
            this.Ausgabe3.Name = "Ausgabe3";
            this.Ausgabe3.Size = new System.Drawing.Size(68, 30);
            this.Ausgabe3.TabIndex = 8;
            // 
            // Ausgabe2
            // 
            this.Ausgabe2.Location = new System.Drawing.Point(136, 35);
            this.Ausgabe2.Multiline = true;
            this.Ausgabe2.Name = "Ausgabe2";
            this.Ausgabe2.Size = new System.Drawing.Size(68, 30);
            this.Ausgabe2.TabIndex = 7;
            // 
            // Ausgabe1
            // 
            this.Ausgabe1.Location = new System.Drawing.Point(31, 35);
            this.Ausgabe1.Multiline = true;
            this.Ausgabe1.Name = "Ausgabe1";
            this.Ausgabe1.Size = new System.Drawing.Size(68, 30);
            this.Ausgabe1.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox Eingabe6;
        private System.Windows.Forms.TextBox Eingabe5;
        private System.Windows.Forms.TextBox Eingabe4;
        private System.Windows.Forms.TextBox Eingabe3;
        private System.Windows.Forms.TextBox Eingabe2;
        private System.Windows.Forms.TextBox Eingabe1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox Ausgabe6;
        private System.Windows.Forms.TextBox Ausgabe5;
        private System.Windows.Forms.TextBox Ausgabe4;
        private System.Windows.Forms.TextBox Ausgabe3;
        private System.Windows.Forms.TextBox Ausgabe2;
        private System.Windows.Forms.TextBox Ausgabe1;
        private System.Windows.Forms.Button button1;
    }
}

