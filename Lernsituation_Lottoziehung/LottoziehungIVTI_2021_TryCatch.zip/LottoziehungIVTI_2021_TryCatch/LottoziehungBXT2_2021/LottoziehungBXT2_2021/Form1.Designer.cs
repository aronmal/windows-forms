﻿
namespace LottoziehungBXT2_2021
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.Eingabe1 = new System.Windows.Forms.TextBox();
            this.Eingabe2 = new System.Windows.Forms.TextBox();
            this.Eingabe4 = new System.Windows.Forms.TextBox();
            this.Eingabe3 = new System.Windows.Forms.TextBox();
            this.Eingabe6 = new System.Windows.Forms.TextBox();
            this.Eingabe5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Ausgabe6 = new System.Windows.Forms.TextBox();
            this.Ausgabe5 = new System.Windows.Forms.TextBox();
            this.Ausgabe4 = new System.Windows.Forms.TextBox();
            this.Ausgabe3 = new System.Windows.Forms.TextBox();
            this.Ausgabe2 = new System.Windows.Forms.TextBox();
            this.Ausgabe1 = new System.Windows.Forms.TextBox();
            this.btLottoziehung = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Eingabe1
            // 
            this.Eingabe1.Location = new System.Drawing.Point(97, 74);
            this.Eingabe1.Multiline = true;
            this.Eingabe1.Name = "Eingabe1";
            this.Eingabe1.Size = new System.Drawing.Size(67, 36);
            this.Eingabe1.TabIndex = 0;
            // 
            // Eingabe2
            // 
            this.Eingabe2.Location = new System.Drawing.Point(182, 74);
            this.Eingabe2.Multiline = true;
            this.Eingabe2.Name = "Eingabe2";
            this.Eingabe2.Size = new System.Drawing.Size(67, 36);
            this.Eingabe2.TabIndex = 1;
            // 
            // Eingabe4
            // 
            this.Eingabe4.Location = new System.Drawing.Point(349, 74);
            this.Eingabe4.Multiline = true;
            this.Eingabe4.Name = "Eingabe4";
            this.Eingabe4.Size = new System.Drawing.Size(67, 36);
            this.Eingabe4.TabIndex = 3;
            // 
            // Eingabe3
            // 
            this.Eingabe3.Location = new System.Drawing.Point(264, 74);
            this.Eingabe3.Multiline = true;
            this.Eingabe3.Name = "Eingabe3";
            this.Eingabe3.Size = new System.Drawing.Size(67, 36);
            this.Eingabe3.TabIndex = 2;
            // 
            // Eingabe6
            // 
            this.Eingabe6.Location = new System.Drawing.Point(517, 74);
            this.Eingabe6.Multiline = true;
            this.Eingabe6.Name = "Eingabe6";
            this.Eingabe6.Size = new System.Drawing.Size(67, 36);
            this.Eingabe6.TabIndex = 5;
            // 
            // Eingabe5
            // 
            this.Eingabe5.Location = new System.Drawing.Point(432, 74);
            this.Eingabe5.Multiline = true;
            this.Eingabe5.Name = "Eingabe5";
            this.Eingabe5.Size = new System.Drawing.Size(67, 36);
            this.Eingabe5.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Bitte geben Sie Ihren Lotttotipp ab: Zahlen zwischen 1 und 49!";
            // 
            // Ausgabe6
            // 
            this.Ausgabe6.Location = new System.Drawing.Point(517, 276);
            this.Ausgabe6.Multiline = true;
            this.Ausgabe6.Name = "Ausgabe6";
            this.Ausgabe6.ReadOnly = true;
            this.Ausgabe6.Size = new System.Drawing.Size(67, 36);
            this.Ausgabe6.TabIndex = 12;
            // 
            // Ausgabe5
            // 
            this.Ausgabe5.Location = new System.Drawing.Point(432, 276);
            this.Ausgabe5.Multiline = true;
            this.Ausgabe5.Name = "Ausgabe5";
            this.Ausgabe5.ReadOnly = true;
            this.Ausgabe5.Size = new System.Drawing.Size(67, 36);
            this.Ausgabe5.TabIndex = 11;
            // 
            // Ausgabe4
            // 
            this.Ausgabe4.Location = new System.Drawing.Point(349, 276);
            this.Ausgabe4.Multiline = true;
            this.Ausgabe4.Name = "Ausgabe4";
            this.Ausgabe4.ReadOnly = true;
            this.Ausgabe4.Size = new System.Drawing.Size(67, 36);
            this.Ausgabe4.TabIndex = 10;
            // 
            // Ausgabe3
            // 
            this.Ausgabe3.Location = new System.Drawing.Point(264, 276);
            this.Ausgabe3.Multiline = true;
            this.Ausgabe3.Name = "Ausgabe3";
            this.Ausgabe3.ReadOnly = true;
            this.Ausgabe3.Size = new System.Drawing.Size(67, 36);
            this.Ausgabe3.TabIndex = 9;
            // 
            // Ausgabe2
            // 
            this.Ausgabe2.Location = new System.Drawing.Point(182, 276);
            this.Ausgabe2.Multiline = true;
            this.Ausgabe2.Name = "Ausgabe2";
            this.Ausgabe2.ReadOnly = true;
            this.Ausgabe2.Size = new System.Drawing.Size(67, 36);
            this.Ausgabe2.TabIndex = 8;
            // 
            // Ausgabe1
            // 
            this.Ausgabe1.Location = new System.Drawing.Point(97, 276);
            this.Ausgabe1.Multiline = true;
            this.Ausgabe1.Name = "Ausgabe1";
            this.Ausgabe1.ReadOnly = true;
            this.Ausgabe1.Size = new System.Drawing.Size(67, 36);
            this.Ausgabe1.TabIndex = 7;
            // 
            // btLottoziehung
            // 
            this.btLottoziehung.Location = new System.Drawing.Point(182, 172);
            this.btLottoziehung.Name = "btLottoziehung";
            this.btLottoziehung.Size = new System.Drawing.Size(317, 43);
            this.btLottoziehung.TabIndex = 13;
            this.btLottoziehung.Text = "Ziehung";
            this.btLottoziehung.UseVisualStyleBackColor = true;
            this.btLottoziehung.Click += new System.EventHandler(this.btLottoziehung_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btLottoziehung);
            this.Controls.Add(this.Ausgabe6);
            this.Controls.Add(this.Ausgabe5);
            this.Controls.Add(this.Ausgabe4);
            this.Controls.Add(this.Ausgabe3);
            this.Controls.Add(this.Ausgabe2);
            this.Controls.Add(this.Ausgabe1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Eingabe6);
            this.Controls.Add(this.Eingabe5);
            this.Controls.Add(this.Eingabe4);
            this.Controls.Add(this.Eingabe3);
            this.Controls.Add(this.Eingabe2);
            this.Controls.Add(this.Eingabe1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox Eingabe1;
        private System.Windows.Forms.TextBox Eingabe2;
        private System.Windows.Forms.TextBox Eingabe4;
        private System.Windows.Forms.TextBox Eingabe3;
        private System.Windows.Forms.TextBox Eingabe6;
        private System.Windows.Forms.TextBox Eingabe5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Ausgabe6;
        private System.Windows.Forms.TextBox Ausgabe5;
        private System.Windows.Forms.TextBox Ausgabe4;
        private System.Windows.Forms.TextBox Ausgabe3;
        private System.Windows.Forms.TextBox Ausgabe2;
        private System.Windows.Forms.TextBox Ausgabe1;
        private System.Windows.Forms.Button btLottoziehung;
    }
}

